package com.mohamadrizki.nontonyuk.core.utils

import com.mohamadrizki.nontonyuk.core.data.source.local.entity.MovieEntity
import com.mohamadrizki.nontonyuk.core.data.source.local.entity.TvShowEntity
import com.mohamadrizki.nontonyuk.core.domain.model.Movie
import com.mohamadrizki.nontonyuk.core.domain.model.TvShow

object DataMapper {
    fun mapMovieEntitiesToDomain(input: List<MovieEntity>): List<Movie> =
        input.map {
            Movie(
                id = it.id,
                title = it.title,
                rating = it.rating,
                year = it.year,
                date = it.date,
                genre = it.genre,
                duration = it.duration,
                userScore = it.userScore,
                quotes = it.quotes,
                description = it.description,
                image = it.image,
                favorite = it.favorite
            )
        }

    fun mapTvShowEntitiesToDomain(input: List<TvShowEntity>): List<TvShow> =
        input.map {
            TvShow(
                id = it.id,
                title = it.title,
                rating = it.rating,
                year = it.year,
                date = it.date,
                genre = it.genre,
                duration = it.duration,
                userScore = it.userScore,
                quotes = it.quotes,
                description = it.description,
                image = it.image,
                favorite = it.favorite
            )
        }

    fun mapMovieEntityToDomain(input: MovieEntity): Movie =
        Movie(
            id = input.id,
            title = input.title,
            rating = input.rating,
            year = input.year,
            date = input.date,
            genre = input.genre,
            duration = input.duration,
            userScore = input.userScore,
            quotes = input.quotes,
            description = input.description,
            image = input.image,
            favorite = input.favorite
        )

    fun mapTvShowEntityToDomain(input: TvShowEntity): TvShow =
            TvShow(
                id = input.id,
                title = input.title,
                rating = input.rating,
                year = input.year,
                date = input.date,
                genre = input.genre,
                duration = input.duration,
                userScore = input.userScore,
                quotes = input.quotes,
                description = input.description,
                image = input.image,
                favorite = input.favorite
            )

    fun mapDomainToMovieEntity(input: Movie) = MovieEntity(
        id = input.id,
        title = input.title,
        rating = input.rating,
        year = input.year,
        date = input.date,
        genre = input.genre,
        duration = input.duration,
        userScore = input.userScore,
        quotes = input.quotes,
        description = input.description,
        image = input.image,
        favorite = input.favorite
    )

    fun mapDomainToTvShowEntity(input: TvShow) = TvShowEntity(
        id = input.id,
        title = input.title,
        rating = input.rating,
        year = input.year,
        date = input.date,
        genre = input.genre,
        duration = input.duration,
        userScore = input.userScore,
        quotes = input.quotes,
        description = input.description,
        image = input.image,
        favorite = input.favorite
    )
}