package com.mohamadrizki.nontonyuk.core.data

import androidx.lifecycle.LiveData
import com.mohamadrizki.nontonyuk.core.domain.model.Movie
import com.mohamadrizki.nontonyuk.core.domain.model.TvShow

interface MovieTvDataSource {
    fun getAllMovies(): LiveData<Resource<List<Movie>>>

    fun getAllTvs(): LiveData<Resource<List<TvShow>>>

    fun getMovie(id: Int): LiveData<Movie>

    fun getTv(id: Int): LiveData<TvShow>

    fun getMovieFavorite(): LiveData<List<Movie>>

    fun getTvShowFavorite(): LiveData<List<TvShow>>

    fun setMovieFavorite(movie: Movie, state: Boolean)

    fun setTvShowFavorite(tvShow: TvShow, state: Boolean)
}